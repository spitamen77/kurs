<?php
/**
 * Created by PhpStorm.
 * Author: Abdujalilov Dilshod
 * Telegram: https://t.me/coloterra
 * Web: http://code.uz
 * Date: 29.03.2019 20:18
 * Content: "Simplex CMS"
 * Site: http://simplex.uz
 */

namespace app\controllers;


use Yii;

use yii\filters\AccessControl;
use yii\filters\auth\HttpBasicAuth;
use yii\filters\auth\HttpBearerAuth;
use yii\helpers\Url;
use yii\rest\Controller;
use yii\web\Response;


class Api2Controller extends Controller
{

    public function behaviors()
    {
        $behaviors = parent::behaviors();
        $behaviors['authenticator']['authMethods'] = [
                HttpBasicAuth::className(),
                HttpBearerAuth::className(),
        ];
        $behaviors['access'] = [
            'class'=>AccessControl::className(),
            'rules'=>[
                [
                    'allow'=>true,
                    'roles'=>['@']
                ],
            ],
        ];
        return $behaviors;
    }

    protected function verbs()
    {
        return [
            'index'=>['get'],
        ];
    }

    public function beforeAction($action)
    {
        $this->enableCsrfValidation = false;
        return parent::beforeAction($action);

    }

    public function actionIndex()
    {
        return [
            'status' => ['code' => 2, 'message' => 'User blocked by admin'],
            'result' => ['salom'=>'qalaysan']
        ];
    }

}