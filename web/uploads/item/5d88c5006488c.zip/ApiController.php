<?php
/**
 * Created by PhpStorm.
 * Author: Abdujalilov Dilshod
 * Telegram: https://t.me/coloterra
 * Web: http://code.uz
 * Date: 29.03.2019 20:18
 * Content: "Simplex CMS"
 * Site: http://simplex.uz
 */

namespace app\controllers;


use app\models\LoginForm;
use app\modules\nextadmin\modules\users\models\UserSecurity;
use Yii;

use yii\helpers\Url;
use yii\rest\Controller;
use yii\web\Response;


class ApiController extends Controller
{
    public function init()
    {
        parent::init();
        \Yii::$app->user->enableSession = false;
    }

    public function actionIndex()
    {
        return "Api";
    }

    public function actionLogin()
    {
        $model = new LoginForm();
        if ($model->load(\Yii::$app->request->getBodyParams(),'') && $model->login()){
            return ['token'=>\Yii::$app->user->identity->auth_key];
        }
        else $this->Unauthorized();
    }

    protected function verbs()
    {
        return [
            'test'=>['post'],
        ];
    }


    public function Unauthorized()
    {
        Yii::$app->response->setStatusCode(401);
        return [
            "name"=> "Unauthorized",
            "message" => "You are requesting with an invalid credential.",
            "code" => 0,
            "status" => 401,
            ];
    }


}